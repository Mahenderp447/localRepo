import { Component, OnInit, Inject } from '@angular/core';
import { EmpdetService } from '../empdet.service';

@Component({
  selector: 'app-employeedetails',
  templateUrl: './employeedetails.component.html',
  styleUrls: ['./employeedetails.component.css']
})
export class EmployeedetailsComponent implements OnInit {
  fn: any;
  ln: any;
  dn: any;
  em: any;
  gen: any;
  addr: any;

  constructor(@Inject(EmpdetService)public ser) {
    this.Submit()
   }

  ngOnInit() {
  }
  Submit(){
    alert("submitting form")
  var obj={
    firstname:this.fn,
    lastname:this.ln,
    designation:this.dn,
    email:this.em,
    gender:this.gen,
    adress:this.addr,
  }
    this.ser.serInsEmpdet(obj).subscribe(dt=>{
alert(dt)
    })
  }

}

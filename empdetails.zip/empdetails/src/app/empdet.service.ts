import { Injectable, Inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class EmpdetService {
  constructor(@Inject(HttpClient) public ht) { }


  //method to insert Employee data to database
  serInsEmpdet(obj){
return this.ht.post("empref/InsertEmpDet",obj)
  }

}


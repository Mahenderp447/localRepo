import { TestBed } from '@angular/core/testing';

import { EmpdetService } from './empdet.service';

describe('EmpdetService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: EmpdetService = TestBed.get(EmpdetService);
    expect(service).toBeTruthy();
  });
});
